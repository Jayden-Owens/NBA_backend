import user from './user';
import player from './player';
import subscription from './subscription';

export default {
  player,
  subscription,
  user
};
